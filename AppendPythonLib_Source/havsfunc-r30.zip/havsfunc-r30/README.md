Dependent modules:
* [mvsfunc](https://github.com/HomeOfVapourSynthEvolution/mvsfunc)
* [adjust](https://github.com/dubhater/vapoursynth-adjust)
* [nnedi3_resample](https://github.com/mawen1250/VapourSynth-script)
