﻿
These files are only a subset of the FFTReal library. Please check
http://ldesoras.free.fr/prod.html#src_fftreal for more information.
