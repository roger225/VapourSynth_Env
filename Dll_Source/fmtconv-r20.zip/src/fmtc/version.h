#pragma once

#define fmtc_VERSION     "r20"
#define fmtc_PLUGIN_NAME "fmtconv"
#define fmtc_NAMESPACE   "fmtc"
